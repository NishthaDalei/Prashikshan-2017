# -*- coding: utf-8 -*-
"""
**************************************************************************
*                  IMAGE PROCESSING (Prashikshan 2017)
*                  ================================
*  This software is intended to teach image processing concepts
*
*  MODULE: Task2C
*  Filename: getCellVal.py
*  Version: 1.0.0  
*  Date: May 3, 2017
*  
*  Author: Prashikshan Team.
**************************************************************************
"""
# detectCellVal detects the numbers/operatorsm,
# perform respective expression evaluation
# and stores them into the grid_map 
# detectCellVal(img,grid_map)

# Find the number/operators, perform the calculations and store the result into the grid_map
# Return the resultant grid_map
import cv2
import numpy as np
# code for detectCellVal
def detectCellVal(img,a):
        list1=[]
        grid1=[]
        grid2=[]
        arr=[]
        d=[]
        C,H,W=img.shape[::-1]
        gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)  #converting rgb  image to gray
        ret,thresh=cv2.threshold(gray,47,255,cv2.THRESH_BINARY)
        contours,hierarchy=cv2.findContours(thresh[:,:,],cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)#Finding contours
        j=1
        s=0
        m=0
        n=0
        t=0
        s1=0
        r1=0
        s2=0
        r2=0
        s3=0
        r3=0
        s4=0
        r4=0
        s5=0
        r5=0
        s6=0
        r6=0
        p1=0
        p2=0
        p3=0
        p4=0
        p5=0
        p6=0
        p7=0
        p8=0
        p9=0
        p10=0
        p11=0
        p12=0
        f=0
        c1=0
        for i in range (len(contours)):
            perimeter=cv2.arcLength(contours[i],True) #calculating contour perimeter
            cnt = contours[i]
            area = cv2.contourArea(cnt) #calculating contour area
            #print area
            #detects only contours having area greater than 850
            if area>850:
                if perimeter>250 and perimeter<450:
                    list1.append(i)  
        for x in list1:
            M=cv2.moments(contours[x])  #calculating moment
            cx = int(M['m10']/M['m00']) #getting the centroid value of the contours
            cy = int(M['m01']/M['m00'])
            #cv2.rectangle(img,(cx-49,cy-49),(cx+49,cy+49),(0,255,255),3)
            cropped=img[cy-49:cy+49,cx-49:cx+49]
            #cv2.imshow('cropped',cropped)
            for i in range (12):
                template=cv2.imread(""+str(i)+".jpg")
                result=cv2.matchTemplate(cropped,template,cv2.TM_CCOEFF_NORMED)
                min_val,max_val,min_loc,max_loc=cv2.minMaxLoc(result)
                 
                        
                if(max_val>0.65 or (max_val<-0.3 and max_val>-0.4)):
                        
                        if (i==8 and max_val<=0.855):
                             break
                
                        grid1.append(i)
        #print grid1[::-1]
        grid2=grid1[::-1] #stores value in reverse manner
        arr=np.array(grid2,dtype=None,copy=True,order='C',subok=False,ndmin=2) #stores values in array
        #np.disp(arr)
        c=arr[0]
        s=len(arr[0]) #finds length of array
        if(s==31):
            for i in range (s):
                if c[i]==8:
                    m=i+1
        elif(s==32):            
            for i in range (s):
                if (c[i]==8 and t==0):
                        f=i+1
                        t=t+1
                elif(c[i]==8 and t==1):
                        n=i+1
        for i in range(s):
            if(i==m or i==n or f==i):
                continue
            d.append(c[i])
        # detecting whether plus or minus will be carried out
        c1=c[0]
        if (d[0]==11):
                p1=11
        elif(d[0]==10):
                p1=10
        if (d[2]==11):
                p2=11
        elif(d[2]==10):
                p2=10
        if (d[5]==11):
                p3=11
        elif(d[5]==10):
                p3=10
        if (d[7]==11):
                p4=11
        elif(d[7]==10):
                p4=10

        if (d[10]==11):
                p5=11
        elif(d[10]==10):
                p5=10
        if (d[12]==11):
                p6=11
        elif(d[12]==10):
                p6=10
        if (d[15]==11):
                p7=11
        elif(d[15]==10):
                p7=10
        if (d[17]==11):
                p8=11
        elif(d[17]==10):
                p8=10
        if (d[20]==11):
                p9=11
        elif(d[20]==10):
                p9=10
        if (d[22]==11):
                p10=11
        elif(d[22]==10):
                p10=10
        if (d[25]==11):
                p11=11
        elif(d[25]==10):
                p11=10
        if (d[27]==11):
                p12=11
        elif(d[27]==10):
                p12=10
        #calculations (mathematical operations)
        if (p1==11):
            s1=c1+d[1]
        else :
            s1=c1-d[1]
        if (p2==11):
            r1=s1+d[3]
        else:
            r1=s1-d[3]
        if (p3==11):
            s2=d[4]+d[6]
        else :
            s2=d[4]-d[6]
        if (p4==11):
            r2=s2+d[8]
        else:
            r2=s2-d[8]
        if (p5==11):
            s3=d[9]+d[11]
        else :
            s3=d[9]-d[11]
        if (p6==11):
            r3=s3+d[13]
        else:
            r3=s3-d[13]
        if (p7==11):
            s4=d[14]+d[16]
        else :
            s4=d[14]-d[16]
        if (p8==11):
            r4=s4+d[18]
        else:
            r4=s4-d[18]
        if (p9==11):
            s5=d[19]+d[21]
        else :
            s5=d[19]-d[21]
        if (p10==11):
            r5=s5+d[23]
        else:
            r5=s5-d[23]
        if (p11==11):
            s6=d[24]+d[26]
        else :
            s6=d[24]-d[26]
        if (p12==11):
            r6=s6+d[28]
        else:
            r6=s6-d[28]
        #Converting results into text
        q=str(r1)         
        q1=str(r2)
        q2=str(r3)
        q3=str(r4)
        q4=str(r5)
        q5=str(r6)
       
        grid_line_x = 7
        grid_line_y = 7
        m=600/(grid_line_x-1)
        n=600/(grid_line_y-1)
        #printing results on the image 
        x,y=(550,50)
        cv2.putText(img, q , (x-m/4, y+n/4),cv2.FONT_HERSHEY_PLAIN, 3, (0,0,255), 4)
        x,y=(550,150)
        cv2.putText(img, q1 , (x-m/4, y+n/4),cv2.FONT_HERSHEY_PLAIN, 3, (0,0,255), 4)
        x,y=(550,250)
        cv2.putText(img, q2 , (x-m/4, y+n/4),cv2.FONT_HERSHEY_PLAIN, 3, (0,0,255), 4)
        x,y=(550,350)
        cv2.putText(img, q3 , (x-m/4, y+n/4),cv2.FONT_HERSHEY_PLAIN, 3, (0,0,255), 4)
        x,y=(550,450)
        cv2.putText(img, q4 , (x-m/4, y+n/4),cv2.FONT_HERSHEY_PLAIN, 3, (0,0,255), 4)
        x,y=(550,550)
        cv2.putText(img, q5 , (x-m/4, y+n/4),cv2.FONT_HERSHEY_PLAIN, 3, (0,0,255), 4)
        
      
        #cv2.imshow("original",img)
        #cv2.waitKey(0)
        #cv2.destroyAllWindows


        #returning image
	return img
