# -*- coding: utf-8 -*-
"""
**************************************************************************
*                  IMAGE PROCESSING (Prashikshan 2017)
*                  ================================
*  This software is intended to teach image processing concepts
*
*  MODULE: Task2A
*  Filename: gridWrite.py
*  Version: 1.0.0  
*  Date: May 3, 2017
*  
*  Author: Prashikshan Team.
**************************************************************************
"""
# Read the gridImage.jpg and display it.
# Go through the below code, it will write the numeral with and without their signs
# on the gridImage
# At the end, output the resultant image as output.jpg and also save it.
#=============================================================
#					Task2A begins	
import cv2
import numpy as np  
# Image size is of 600 by 600 pixels. 
# Total gridlines are 7 veticals lines and 7 Horizontals lines
grid_line_x = 7
grid_line_y = 7
m=600/(grid_line_x-1)
n=600/(grid_line_y-1)
# Read Image
img_rgb = cv2.imread('demo.jpg')
x,y=(50,50)
cv2.putText(img_rgb, '0', (x-m/4, y+n/4),cv2.FONT_HERSHEY_PLAIN, 5, (0,0,255), 4)
x,y=(150,50)
cv2.putText(img_rgb, '0', (x-m/4, y+n/4),cv2.FONT_HERSHEY_PLAIN, 5, (0, 0, 255), 4)
x,y=(250,50)
cv2.putText(img_rgb, '0', (x-m/4, y+n/4),cv2.FONT_HERSHEY_PLAIN, 5, (0, 0, 255), 4)
x,y=(50,150)
cv2.putText(img_rgb, '0', (x-m/4, y+n/4),cv2.FONT_HERSHEY_PLAIN, 5, (0, 0, 255), 4)
x,y=(150,150)
cv2.putText(img_rgb, '0', (x-m/4, y+n/4),cv2.FONT_HERSHEY_PLAIN, 5, (0, 0, 255), 4)
x,y=(250,150)
cv2.putText(img_rgb, '0', (x-m/4, y+n/4),cv2.FONT_HERSHEY_PLAIN, 5, (0, 0, 255), 4)
x,y=(50,250)
cv2.putText(img_rgb, '0', (x-m/4, y+n/4),cv2.FONT_HERSHEY_PLAIN, 5, (0, 0, 255), 4)
x,y=(150,250)
cv2.putText(img_rgb, '0', (x-m/4, y+n/4),cv2.FONT_HERSHEY_PLAIN, 5, (0, 0, 255), 4)
x,y=(250,250)
cv2.putText(img_rgb, '0', (x-m/4, y+n/4),cv2.FONT_HERSHEY_PLAIN, 5, (0, 0, 255), 4)
x,y=(50,350)
cv2.putText(img_rgb, '0', (x-m/4, y+n/4),cv2.FONT_HERSHEY_PLAIN, 5, (0, 0, 255), 4)
x,y=(150,350)
cv2.putText(img_rgb, '0', (x-m/4, y+n/4),cv2.FONT_HERSHEY_PLAIN, 5, (0, 0, 255), 4)
x,y=(250,350)
cv2.putText(img_rgb, '0', (x-m/4, y+n/4),cv2.FONT_HERSHEY_PLAIN, 5, (0, 0, 255), 4)
x,y=(50,450)
cv2.putText(img_rgb, '0', (x-m/4, y+n/4),cv2.FONT_HERSHEY_PLAIN, 5, (0, 0, 255), 4)
x,y=(150,450)
cv2.putText(img_rgb, '0', (x-m/4, y+n/4),cv2.FONT_HERSHEY_PLAIN, 5, (0, 0, 255), 4)
x,y=(250,450)
cv2.putText(img_rgb, '0', (x-m/4, y+n/4),cv2.FONT_HERSHEY_PLAIN, 5, (0, 0, 255), 4)
x,y=(50,550)
cv2.putText(img_rgb, '0', (x-m/4, y+n/4),cv2.FONT_HERSHEY_PLAIN, 5, (0, 0, 255), 4)
x,y=(150,550)
cv2.putText(img_rgb, '0', (x-m/4, y+n/4),cv2.FONT_HERSHEY_PLAIN, 5, (0, 0, 255), 4)
x,y=(250,550)
cv2.putText(img_rgb, '0', (x-m/4, y+n/4),cv2.FONT_HERSHEY_PLAIN, 5, (0, 0, 255), 4)
x,y=(550,50)
cv2.putText(img_rgb, '0', (x-m/4, y+n/4),cv2.FONT_HERSHEY_PLAIN, 5, (0, 0, 255), 4)
x,y=(550,150)
cv2.putText(img_rgb, '0', (x-m/4, y+n/4),cv2.FONT_HERSHEY_PLAIN, 5, (0, 0, 255), 4)
x,y=(550,250)
cv2.putText(img_rgb, '0', (x-m/4, y+n/4),cv2.FONT_HERSHEY_PLAIN, 5, (0, 0, 255), 4)
x,y=(550,350)
cv2.putText(img_rgb, '0', (x-m/4, y+n/4),cv2.FONT_HERSHEY_PLAIN, 5, (0, 0, 255), 4)
x,y=(550,450)
cv2.putText(img_rgb, '0', (x-m/4, y+n/4),cv2.FONT_HERSHEY_PLAIN, 5, (0, 0, 255), 4)
x,y=(550,550)
cv2.putText(img_rgb, '0', (x-m/4, y+n/4),cv2.FONT_HERSHEY_PLAIN, 5, (0, 0, 255), 4)
#img1=cv2.imread('4.jpg',0)
#img2=cv2.imread('5.jpg',0)
#cv2.matMulDerive(100, 100)

   
#img= [ [ row[x][y] for i in range(grid_line_y-1) ] for j in range(grid_line_x-1) ]
#print d
# Show the image
# Show the image
cv2.imshow('output1',img_rgb)
# Write the image
cv2.imwrite('output1.jpg',img_rgb)
cv2.waitKey()
cv2.waitKey()
#=============================================================
# Your task2A ends here

